package ds.edu.dictionaryapp;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Class that represent a DictionaryApp. The implementation was
 * completely based on the AndroidInterestingPicture app provided in the class
 * materials. Find link in: https://github.com/CMU-Heinz-95702/AndroidInterestingPicture
 */
public class Dictionary extends AppCompatActivity {
    Dictionary me = this; // Reference to itself

    /**
     * On Create method. Sets the listener required for the dictionary functionality.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState); // Calls parent onCreate method
        setContentView(R.layout.activity_main); // Displays the main activity content

        final Dictionary dic = this; // Reference to the current object
        Button submitButton = (Button)findViewById(R.id.button); // Finds the "submit" button

        submitButton.setOnClickListener(new View.OnClickListener(){ // Adds a listener to the send button
            public void onClick(View viewParam) {
                String searchTerm = ((EditText)findViewById(R.id.editTextText)).getText().toString(); // Extracts the searched word
                GetWord gw = new GetWord(); // Initializes a getWord object
                gw.search(searchTerm, me, dic); // Done asynchronously in another thread.  It calls meaningReady() method in this thread when complete.
            }
        });
    }

    /**
     * Method called from the GetWord object to notify the main thread that the meaning is ready.
     */
    public void meaningReady(String meaning){
        TextView meaningView = (TextView)findViewById(R.id.textView3); // Gets a reference to the meaning view
        TextView searchView = (EditText)findViewById(R.id.editTextText); // Gets a reference to the search view
        if( meaning != null ){ // Validates the meaning is not null
            meaningView.setText(meaning); // Displays the meaning
        }
        searchView.setText(""); // Clears the input space
    }

}