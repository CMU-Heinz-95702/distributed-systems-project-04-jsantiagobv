package ds.edu.dictionaryapp;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import android.app.Activity;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Class that consumes the Web Application resources to get the word meanings. The implementation was
 * completely based on the AndroidInterestingPicture app, GetPicture class provided in the class
 * materials. Find link in: https://github.com/CMU-Heinz-95702/AndroidInterestingPicture
 */
public class GetWord {

    Dictionary dictionary = null; // Reference to the Dictionary activity
    String word = null; // Word which meaning needs to be retrieved
    String response = null; // Response from the web application

    /**
     * Search method. Initializes the background task
     */
    public void search(String word, Activity activity, Dictionary dictionary){
        this.dictionary = dictionary; // Sets the reference to the main thread
        this.word = word.replace(" ", "");; // Gets the searched word
        new BackgroundTask(activity).execute(); // Initializes the background tas
    }


    // class BackgroundTask
    // Implements a background thread for a long running task that should not be
    //    performed on the UI thread. It creates a new Thread object, then calls doInBackground() to
    //    actually do the work. When done, it calls onPostExecute(), which runs
    //    on the UI thread to update some UI widget (***never*** update a UI
    //    widget from some other thread!)
    //
    // Adapted from one of the answers in
    // https://stackoverflow.com/questions/58767733/the-asynctask-api-is-deprecated-in-android-11-what-are-the-alternatives
    // Modified by Barrett
    //
    // Ideally, this class would be abstract and parameterized.
    // The class would be something like:
    //      private abstract class BackgroundTask<InValue, OutValue>
    // with two generic placeholders for the actual input value and output value.
    // It would be instantiated for this program as
    //      private class MyBackgroundTask extends BackgroundTask<String, Bitmap>
    // where the parameters are the String url and the Bitmap image.
    //    (Some other changes would be needed, so I kept it simple.)
    //    The first parameter is what the BackgroundTask looks up on Flickr and the latter
    //    is the image returned to the UI thread.
    // In addition, the methods doInBackground() and onPostExecute( ) could be
    //    absttract methods; would need to finesse the input and ouptut values.
    // The call to activity.runOnUiThread( ) is an Android Activity method that
    //    somehow "knows" to use the UI thread, even if it appears to create a
    //    new Runnable.
    /**
     * BackgroundTask class. Implemented following the implementation of
     * AndroidInterestingPicture
     */
    private class BackgroundTask{
        private static final String REQUEST_URL = "https://fluffy-lamp-wrgrvwvxxv5xf5vjq-8080.app.github.dev/word/"; // Request URL
        private Activity activity; // The UI thread

        /**
         * Builder method of the BackgroundTask
         */
        public BackgroundTask(Activity activity) { this.activity = activity; } // Saves the reference to main activity

        /**
         * Starts the background activity
         */
        private void startBackground() {
            new Thread( new Runnable() { // Initializes a new thread
                public void run() {
                    doInBackground();
                    // This is magic: activity should be set to MainActivity.this
                    // then this method uses the UI thread
                    activity.runOnUiThread(new Runnable() {
                        public void run() { onPostExecute(); } // Indicates what to do after execution
                    });
                }
            }).start(); // Starts the background thread
        }

        /**
         * Starts the background thread
         */
        private void execute(){ startBackground(); }

        /**
         * Calls the search method in background
         */
        private void doInBackground() { response = search(word); }

        /**
         * Calls the meaningReady method on the main thread to display the results
         */
        public void onPostExecute( ) { dictionary.meaningReady(response);}

        /**
         * Searches the word meaning by consuming the Web Application services
         * This method was made with the help of ChatGPT to the part when I read
         * the response
         */
        private String search(String word){

            if(!WordValidator.validateWord(word)) return "Please provide a valid word!"; // Validates having an appropriate word

            StringBuilder result = new StringBuilder(); // Initializes a StringBuilder object
            try {
                URL url = new URL(REQUEST_URL + word); // Consolidates the request url
                HttpURLConnection connection = (HttpURLConnection) url.openConnection(); // Establishes a connection with the web server
                connection.setRequestMethod("GET"); // Sets a GET request
                connection.setConnectTimeout(5000); // Sets Timeout settings
                connection.setReadTimeout(5000); // Sets Timeout settings

                int responseCode = connection.getResponseCode(); // Check if the connection was successful

                if (responseCode == HttpURLConnection.HTTP_OK) { // Processes the response if it is ok
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream())); // Creates a buffered reader
                    String line; // Creates a String to read the response
                    while ((line = reader.readLine()) != null) result.append(line); // Reads the response
                    reader.close(); // Closes the connection

                } else if((responseCode+"").startsWith("5")) return "We found on error connecting to the server.\nPlease try again later!"; // Returns a message if there is a server issue
                else return "Searched term is not part of Santiago's Dictionary.\nTry with a new one!"; // Returns other error message
            } catch (Exception e) { // Catches an exception
                return "We found on error connecting to the server.\nPlease try again later!"; // Returns other error message
            }
            return parseJson(result.toString()); // Returns the server response
        }

        /**
         * Converts the web application json into a String yo be displayed in the app
         * This code was made with Blackbox.ai
         */
        private String parseJson(String jsonString) {
            try {
                StringBuilder result = new StringBuilder(); // Initializes a StringBuilder

                // Parse the outer JSON object
                JSONObject jsonObject = new JSONObject(jsonString); // Gets outer json object
                String status = jsonObject.getString("status"); // Gets the response status
                String bodyString = jsonObject.getString("body"); // Gets the response body

                // Parse the inner JSON string
                JSONObject bodyObject = new JSONObject(bodyString); // Gets the inner json
                String word = bodyObject.getString("word"); // Gets the searched word
                result.append(word).append("\n"); // Adds the word to the string

                if (bodyObject.has("phonetic")) { // Validates if the meaning has phonetics
                    String phonetic = bodyObject.getString("phonetic"); // Gets the phonetics
                    result.append("/").append(phonetic).append("/\n"); // Adds the phonetics to the string
                }

                JSONArray meaningsArray = bodyObject.getJSONArray("meanings"); // Gets the array with the possible meanings
                for (int i = 0; i < meaningsArray.length(); i++) { // Loop through meanings
                    JSONObject meaningObject = meaningsArray.getJSONObject(i); // Gets the meaning json object
                    String partOfSpeech = meaningObject.getString("partOfSpeech"); // Gets the part of speech
                    String definition = meaningObject.getString("definition"); // Gets the definition of the word
                    result.append((i+1)).append(". ").append(partOfSpeech).append(". ").append(definition).append(".\n"); // Writes the definition in the string builder
                }
                return result.toString(); // Returns the result
            } catch (JSONException e) { // Catches a Json Exception.
                e.printStackTrace(); // Prints a stack trace
            }
            return "Unable to parse server's response for this request."; // Returns a default answer
        }
    }
}
