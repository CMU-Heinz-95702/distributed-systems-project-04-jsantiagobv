package ds.edu.dictionaryapp;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import java.util.regex.Pattern;

/**
 * Class that validates if a word is correct before consuming the API
 * I made this class with ChatGPT
 */
public class WordValidator {

    /**
     * Static method that validates the input
     */
    public static boolean validateWord(String input){
        if (input == null || input.isEmpty()) { // Validates if the word is null or empty
            return false; // Returns false
        }
        Pattern pattern = Pattern.compile("^[a-zA-Z]+$"); // Regex to match alphabetic words (only letters, no numbers or special characters)
        return pattern.matcher(input).matches(); // Returns if the word is valid
    }
}
