package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import java.util.ArrayList;

/**
 * Class that represents a Word in the structure of the API server
 */
public class APIWord {
    String word; // Searched word
    String phonetic; // Phonetics of the word
    ArrayList<APIPhonetic> phonetics; // Detailed phonetics of the word
    String origin; // Origin od the word
    ArrayList<APIMeaning> meanings; // Possible meanings of the word
}

/**
 * Class that represents a Phonetic in the structure of the API server
 */
class APIPhonetic {
    String text; // Text representation of the word
    String audio; // Link to an audio
}

/**
 * Class that represents a Meaning in the structure of the API server
 */
class APIMeaning {
    String partOfSpeech; // Type of word
    ArrayList<APIDefinition> definitions; // Possible definitions of the word
}

/**
 * Class that represents a Definition in the structure of the API server
 */
class APIDefinition {
    String definition; // Definition of the word
    String example; // Example of how to use the word in a sentence
    ArrayList<String> synonyms; // Possible synonyms of the word
    ArrayList<String> antonyms; // Possible antonyms of the word
}
