package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Class that represents a Dictionary Model. It is the Model in the MVC architecture.
 * Implementation based on the InterestingPicture program.
 * See link on: https://github.com/CMU-Heinz-95702/Lab2-InterestingPicture
 */
public class DictionaryModel {

    private final static String API_URL = "https://api.dictionaryapi.dev/api/v2/entries/en/"; // API url (for making requests)
    private Gson gson; //Gson object to parse the API response

    /**
     * Builder method of the Class
     */
    public DictionaryModel() { gson = new Gson();} // Initializes the Gson object

    /**
     * Search the definition of a word using the API.
     * Implementation based on doFlickrSearch method in InterestingPictureLab
     */
    public String searchWord(String word, MongoLogger Logger) throws UnsupportedEncodingException, InvalidWordException, Exception, IOException {
        WordValidator.validateWord(word); // Validates that the received word is valid
        word = URLEncoder.encode(word, "UTF-8"); // Uses the appropriate encoder
        String apiResponse = ""; // Declares a string for the apiResponse
        String urlString = API_URL + word; // Consolidates the url request
        Logger.setApiRequestTime(new Date()); // Logs the API request time
        apiResponse = fetch(urlString, Logger); // Gets the API response
        Logger.setApiReplyTime(new Date()); // Logs the API response time

        Word adjusted = adjustResponse(apiResponse); // Adjust the response of the API with the required attributes
        return gson.toJson(adjusted); // Returns the adjusted word in Json format
    }

    /**
     * Fetch the API request
     * Implementation completely taken from InterestingPicture Lab
     */
    private String fetch(String urlString, MongoLogger Logger) throws IOException{
        String response = "";
        URL url = new URL(urlString);
        /*
         * Create an HttpURLConnection.  This is useful for setting headers
         * and for getting the path of the resource that is returned (which
         * may be different than the URL above if redirected).
         * HttpsURLConnection (with an "s") can be used if required by the site.
         */
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        Logger.setApiResponseCode(connection.getResponseCode()); // Logs the API response code
        Logger.setApiResponseCodeDescription(connection.getResponseMessage()); // Logs the API response message

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream(), "UTF-8")); // Read all the text returned by the server
        String str; // Declares a string for the resposne

        while ((str = in.readLine()) != null) { // Read each line of "in" until done, adding each to "response"
            response += str; // str is one line of text readLine() strips newline characters
        }
        in.close(); // Closes the connection
        return response; // Returns the response
    }

    /**
     * Method that parses the API response to an object of the Word class.
     * I requested ChatGPT to implement this method giving it the structure of the APO response
     * and the structure of the Word class.
     */
    private Word adjustResponse(String response) throws Exception {
        try {
            Type listType = new TypeToken<List<APIWord>>() {}.getType(); // Define the type of the list
            List<APIWord> wordDataList = gson.fromJson(response, listType); // Parse JSON to List<WordData>
            Word word = new Word(); // Initializes a new Word object
            word.meanings = new ArrayList<>(); // Initializes the meanings array
            for (APIWord wordData : wordDataList) { // Iterates over the response to get the possible meanings
                word.word = wordData.word; // Sets the word
                word.phonetic = wordData.phonetic; // Sets the phonetics
                for (APIMeaning meaningData : wordData.meanings) { // Iterates the meanings
                    for (APIDefinition definition : meaningData.definitions) { // Iterates the definitions
                        Meaning meaning = new Meaning(); // Initializes a new meaning
                        meaning.partOfSpeech = meaningData.partOfSpeech; // Sets the part of the speech
                        meaning.definition = definition.definition; // Sets a definition
                        word.meanings.add(meaning); // Adds the meaning
                    }
                }
            }
            int max = Math.min(word.meanings.size(), 7); // Defines the max amount of definitions that will be retrieved
            List<Meaning> subset = word.meanings.subList(0, max); // Creates a subset with 7 elements at most
            word.meanings = new ArrayList<>(subset); // Assigns the subset to the meanings
            return word; // Returns the word
        } catch (Exception e) { // Catch any exception
            throw new Exception(); // Throws a new Exception
        }
    }
}
