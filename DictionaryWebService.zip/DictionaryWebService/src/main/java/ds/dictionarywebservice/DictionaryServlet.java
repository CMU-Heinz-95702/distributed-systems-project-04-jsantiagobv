package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import com.google.gson.JsonObject;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

/**
 * Class that represents the Controller for the Web Application.
 * It receives 2 kinds of request:
 *  - word: the multiple definitions of a word
 *  - dashboard: the operation analytics of the application
 */
@WebServlet(name = "helloServlet", urlPatterns = {"/word/*", "/dashboard"})
public class DictionaryServlet extends HttpServlet {

    private DictionaryModel dictionary; // Dictionary model

    /**
     * Init method. Creates an instance of the DictionaryModel
     */
    public void init() { dictionary = new DictionaryModel(); }

    /**
     * Handles the Get requests of the application
     */
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
        String path = request.getServletPath(); // Retrieves the type of request
        if (path.equals("/word")) searchWord(request, response); // Returns the word definitions
        else if (path.equals("/dashboard")) displayDashboard(request, response); // Displays the dashboard statistics and logs
    }

    /**
     * Handles the request and calls the model to search the definitions
     */
    private void searchWord(HttpServletRequest request, HttpServletResponse response) throws IOException{

        MongoLogger Logger = new MongoLogger(); // Initializes a new MongoLogger
        Logger.setAppRequestTime(new Date()); // Registers the current time

        response.setContentType("application/json"); // Sets the response content type to application/json
        response.setCharacterEncoding("UTF-8"); // Sets the encoding type
        JsonObject jsonResponse = new JsonObject(); // Initializes a JsonObject to consolidate the response
        try {
            String word = request.getPathInfo().substring(1); // Retrieves the word
            Logger.setWord(word); // Registers the word in the log
            Logger.setDeviceType(request.getHeader("User-Agent")); // Registers the device type in the log

            String definition = dictionary.searchWord(word, Logger); // Calls the model to search teh word
            response.setStatus(HttpServletResponse.SC_OK); // Assigns the OK status to the response
            jsonResponse.addProperty("status", "ok"); // Adds a status to the Json response
            jsonResponse.addProperty("body", definition); // Adds the body of the response (definitions)

            Logger.setAppResponseCode(HttpServletResponse.SC_OK); // Registers the response type in the log
            Logger.setAppResponseCodeDescription("OK"); // Registers the response message in the log

        } catch (InvalidWordException e) { // Catches the error if the word is invalid
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST); // Assigns the status to the request
            jsonResponse.addProperty("status", "error"); // Assigns the status in the response body
            jsonResponse.addProperty("body", "invalid input"); // Assigns the response body with an explanation

            Logger.setAppResponseCode(HttpServletResponse.SC_BAD_REQUEST); // Registers the response type in the log
            Logger.setAppResponseCodeDescription("Bad Request"); // Registers the response message in the log

        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // Assigns the status to the request
            jsonResponse.addProperty("status", "error"); // Assigns the status in the response body
            jsonResponse.addProperty("body", "information not found"); // Assigns the response body with an explanation

            Logger.setAppResponseCode(HttpServletResponse.SC_INTERNAL_SERVER_ERROR); // Registers the response type in the log
            Logger.setAppResponseCodeDescription("Internal Server Error"); // Registers the response message in the log
        }
        response.getWriter().write(jsonResponse.toString()); // Writes the json response to the client
        Logger.setAppReplyTime(new Date()); // Logs the response time
        Logger.storeLog(); // Requests the logger to store the log in MongoDB

    }

    /**
     * Displays the analytics Dashboard by consuming the information in MongoDB
     */
    private void displayDashboard(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            MongoAnalytics mongoAnalytics = new MongoAnalytics(); // Initializes a new MongoAnalytics object

            // Operation Analytics

            request.setAttribute("numRequests", mongoAnalytics.getNumRequests()); // Assigns the numRequests attribute
            request.setAttribute("creativityRatio", mongoAnalytics.getCreativityRatio()); // Assigns the creativityRatio attribute

            ArrayList<String> mostSearchedWords = mongoAnalytics.getMostSearchedWords(); // Retrieves the most searched words
            StringBuilder builder = new StringBuilder(); // Initializes a new StringBuilder
            for (int i = 0; i < mostSearchedWords.size(); i++) { // Iterates iver the most searched words
                builder.append((i+1)).append(". ").append(mostSearchedWords.get(i)).append("<br>"); // Consolidates the words in HTML format
            }
            request.setAttribute("mostSearchedWords", builder.toString()); // Sets the attribute in the request

            ArrayList<String> mostUsedDevices = mongoAnalytics.getMostUsedDevices(); // Retrieves the most used devices
            builder = new StringBuilder(); // Initializes a new StringBuilder
            for (int i = 0; i < mostUsedDevices.size(); i++) { // Iterates iver the most used devices
                builder.append((i+1)).append(". ").append(mostUsedDevices.get(i)).append("<br>"); // Consolidates the devices in HTML format
            }
            request.setAttribute("mostUsedDevices", builder.toString()); // Sets the attribute in the request

            request.setAttribute("averageRequestTime", mongoAnalytics.getAverageRequestTime()); // Assigns the averageRequestTime attribute

            // Operation Logs

            builder = new StringBuilder(); // Initializes a new StringBuilder
            ArrayList<MongoLog> logs = mongoAnalytics.getLogs(); // Retrieves the logs
            for(MongoLog log : logs) { // Iterates over the logs and format them in HTML format
                builder.append("<b>").append(log.getWord()).append("</b><br>"); // Sets the searched Word
                builder.append("<ul>");

                builder.append("<li>App Request Data<ul>"); // Sets the App Request Data
                builder.append("<li>App Request Time: ").append(formatDate(log.getAppRequestTime())).append("</li>");
                builder.append("<li>Device Type: ").append(log.getDeviceType()).append("</li>");
                builder.append("</ul></li>");

                builder.append("<li>API Request Data<ul>"); // Sets the API Request Data
                builder.append("<li>API Request Time: ").append(formatDate(log.getApiRequestTime())).append("</li>");
                builder.append("<li>API Reply Time: ").append(formatDate(log.getApiReplyTime())).append("</li>");
                builder.append("<li>API Response Code: ").append(log.getApiResponseCode()).append("</li>");
                builder.append("<li>API Response Message: ").append(log.getApiResponseCodeDescription()).append("</li>");
                builder.append("</ul></li>");

                builder.append("<li>App Response Data<ul>"); // Sets the App Response Data
                builder.append("<li>App Reply Time: ").append(formatDate(log.getAppReplyTime())).append("</li>");
                builder.append("<li>App Response Code: ").append(log.getAppResponseCode()).append("</li>");
                builder.append("<li>App Response Message: ").append(log.getAppResponseCodeDescription()).append("</li>");
                builder.append("</ul></li>");

                builder.append("</ul>");
            }
            request.setAttribute("requestsLog", builder.toString()); // Returns the logs to the View
            request.getRequestDispatcher("/dashboard.jsp").forward(request, response); // Displays the dashboard.jsp View

        } catch (ServletException e) { // Catches a new ServletException
            throw new RuntimeException(e); // Displays the error in console
        }
    }

    /**
     * Formats dates in yyyy-MM-dd HH:mm:ss.SSS format
     */
    private String formatDate(Date date) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"); // Defines the format
        if(date != null) { // Validates if teh date is not null
            return sdf.format(date); // Formats the date
        } else return null; // Otherwise returns null
    }

}