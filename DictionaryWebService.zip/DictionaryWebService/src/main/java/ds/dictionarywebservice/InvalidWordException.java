package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

/**
 * InvalidWordException class, this exception is thrown if the requested word has invalid characters/structure
 */
public class InvalidWordException extends Exception {

    /**
     * Default constructor
     */
    public InvalidWordException() {
        super("Invalid input: The value is not a valid word with alphabetic characters."); // Assigns a message
    }

    /**
     * message oriented builder
     */
    public InvalidWordException(String message) {
        super(message); // Assigns the message given as parameter
    }
}
