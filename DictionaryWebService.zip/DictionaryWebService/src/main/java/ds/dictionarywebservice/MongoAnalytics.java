package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import com.mongodb.*;
import com.mongodb.client.*;
import org.bson.Document;
import java.util.*;

/**
 * MongoAnalytics class
 * This class is in charge to retrieve the updated logs  and calculate some operation metrics.
 * This class was build using the MongoDB example in https://www.mongodb.com/developer/languages/java/java-setup-crud-operations/
 * Also, I used ChatGPT and Blackbox.ai
 */
public class MongoAnalytics {

    private static final String connectionString = // URL for the connection with MongoDB
            "mongodb+srv://jsantiagobv:SHIRO123@cluster.y4hq5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster";

    // Mongo references
    private MongoClient mongoClient; // Mongo client
    private MongoDatabase database; // Reference to the Mongo database
    private MongoCollection<Document> collection; // Reference to the Mongo collection

    // Logs and metrics
    private ArrayList<MongoLog> logs; // List with Web Application Logs
    private long numRequests; // Number of requests the application has received
    private double creativityRatio; // Creativity Ratio. Ratio of the words that only have been searched once
    private ArrayList<String> mostSearchedWords; // Most searched words (at most 3)
    private ArrayList<String> mostUsedDevices; // Most used devices (at most 3)
    private double averageRequestTime; // Average time to process a request from the app

    /**
     * Builder method. Creates the connection, download the logs and calculate the metrics.
     */
    public MongoAnalytics(){
        ServerApi serverApi = ServerApi.builder() // Configures the Server API version for MongoDB
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder() // Builds the MongoClientSettings using the connection string and server API configuration
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();
        try {
            mongoClient = MongoClients.create(settings); // Creates a MongoClient instance with the specified settings
            database = mongoClient.getDatabase("project4"); // Gets the reference to the "project4" database
            collection = database.getCollection("dictionary"); // Gets the reference to the "dictionary" collection within the database

        } catch (Exception e){ // Catches an exception if an error occurs
            e.printStackTrace(); // Print the stack trace
        }
        chargeLogs(); // Load logs from the database
        calculateMetrics(); // Perform calculations to derive metrics based on the loaded logs
        mongoClient.close(); // Close the MongoClient connection
    }

    /**
     * Retrieves the logs in MongoDB
     */
    public ArrayList<MongoLog> getLogs() {
        return logs;
    }

    /**
     * Retrieves the number of requests
     */
    public long getNumRequests() {
        return numRequests;
    }

    /**
     * Retrieves the creativity ratio
     */
    public double getCreativityRatio() {
        return creativityRatio;
    }

    /**
     * Retrieves the most searched words
     */
    public ArrayList<String> getMostSearchedWords() {
        return mostSearchedWords;
    }

    /**
     * Retrieves the most used devices
     */
    public ArrayList<String> getMostUsedDevices() {
        return mostUsedDevices;
    }

    /**
     * Retrieves the average request time
     */
    public double getAverageRequestTime() {
        return averageRequestTime;
    }

    /**
     * Charge the logs from MongoDB
     */
    private void chargeLogs(){
        logs = new ArrayList<>(); // Initializes the logs ArrayList

        for (Document doc : collection.find()) { // Iterates over the documents / a document is ONE log
            String word = doc.getString("word"); // Gets the word
            Date appRequestTime = doc.getDate("appRequestTime"); // Gets the app request time
            String deviceType = doc.getString("deviceType"); // Gets the device type
            Date apiRequestTime = doc.getDate("apiRequestTime"); // Gets the api request time
            Date apiReplyTime = doc.getDate("apiReplyTime"); // Gets the api reply time
            Integer apiResponseCode = doc.getInteger("apiResponseCode"); // Gets the api response code
            String apiResponseCodeDescription = doc.getString("apiResponseCodeDescription"); // Gets the api response message
            Date appReplyTime = doc.getDate("appReplyTime"); // Gets the time reply time
            Integer appResponseCode = doc.getInteger("appResponseCode"); // Gets the app response
            String appResponseCodeDescription = doc.getString("appResponseCodeDescription"); // Gets the app response message

            MongoLog log = // Initializes a new MongoLog object with the previous information
                    new MongoLog(word,appRequestTime,deviceType,apiRequestTime,apiReplyTime,apiResponseCode,apiResponseCodeDescription,appReplyTime,appResponseCode,appResponseCodeDescription);
            logs.add(log); // Adds the log in the logs array
        }

    }

    /**
     * Calls all the individual metrics calculation methods
     */
    private void calculateMetrics(){
        calculateNumRequests(); // Calls calculateNumRequests method
        calculateMostSearchedWords(); // Calls calculateMostSearchedWords method
        calculateMostUsedDevices(); // Calls calculateMostUsedDevices method
        calculateCreativityRatio(); // Calls calculateCreativityRatio method
        calculateAverageRequestTime(); // Calls calculateAverageRequestTime method
    }

    /**
     * Updates the numRequest value
     */
    private void calculateNumRequests(){
        numRequests = collection.countDocuments(); // Counts the number of logs/documents
    }

    /**
     * Updates the most searched words
     * This method was made with Blackbox.ai. I gave the structure of the logs and explain the AI
     * what I needed.
     */
    private void calculateMostSearchedWords(){
        Map<String, Integer> wordCountMap = new HashMap<>(); // Map to store word counts

        for(MongoLog log : logs){ // Iterates over the logs
            String word = log.getWord(); // Retrieves the searched word
            if(word != null){ // Validates if the word is not null
                word = word.toLowerCase(); // Validates if the word is not null
                wordCountMap.put(word, wordCountMap.getOrDefault(word, 0) + 1); // Puts the word in the map of increases the value if the word already exists
            }
        }

        // Get top 3 most repeated words
        List<Map.Entry<String, Integer>> wordList = new ArrayList<>(wordCountMap.entrySet()); // Creates an arraylist witht the data from the hashmap
        wordList.sort((a, b) -> b.getValue().compareTo(a.getValue())); // Sort by frequency

        // Save top 3 words
        mostSearchedWords = new ArrayList<>(); // Initializes the mostSearchedWords array
        for (int i = 0; i < Math.min(3, wordList.size()); i++) { // Iterates (at most) the 3 most searched words
            mostSearchedWords.add(wordList.get(i).getKey()); // Adds the word to the mostSearchedWords array
        }
    }

    /**
     * Calculates the creativity ratio.
     * This method was made with Blackbox.ai
     */
    private void calculateCreativityRatio(){
        Map<String, Integer> wordCountMap = new HashMap<>(); // Map to store word counts

        for (MongoLog log : logs) { // Iterates over the logs
            String text = log.getWord(); // Retrieves the searched word
            if (text != null) { // Validates if the word is not null
                text = text.toLowerCase(); // Validates if the word is not null
                wordCountMap.put(text, wordCountMap.getOrDefault(text, 0) + 1); // Puts the word in the map of increases the value if the word already exists
            }
        }

        // Gets the words that only have been searched once
        int unique = 0; // Initializes a counter
        for (Map.Entry<String, Integer> entry : wordCountMap.entrySet()) { // Iterates over the hashmap elements
            if (entry.getValue() == 1){ // Validates if the count of a word is equal to 1
                unique++; // Increases the count if so
            };
        }
        creativityRatio = wordCountMap.size() > 0 ? (double) unique / wordCountMap.size() : 0; // Calculates the creativity ratio
    }

    /**
     * Consolidates a list with the most used devices
     * This method was made with Blackbox.ai
     */
    private void calculateMostUsedDevices(){
        Map<String, Integer> deviceCountMap = new HashMap<>(); // Map to store device counts

        for (MongoLog log : logs) { // Iterates over the logs
            String device = log.getDeviceType(); // Retrieves the device type
            if (device != null) { // Validates if the device is not null
                deviceCountMap.put(device, deviceCountMap.getOrDefault(device, 0) + 1); // Puts the device type in the map of increases the value if the device already exists
            }
        }

        // Get top 3 most repeated devices
        List<Map.Entry<String, Integer>> deviceList = new ArrayList<>(deviceCountMap.entrySet()); // Creates an arraylist witht the data from the hashmap
        deviceList.sort((a, b) -> b.getValue().compareTo(a.getValue())); // Sort by frequency

        // Save top 3 device types
        mostUsedDevices = new ArrayList<>(); // Initializes the mostUsedDevices array
        for (int i = 0; i < Math.min(3, deviceList.size()); i++) { // Iterates (at most) the 3 most used devices
            mostUsedDevices.add(deviceList.get(i).getKey()); // Adds the device to the mostUsedDevices array
        }
    }

    /**
     * Calculates the average response time of a request
     * This method was implemented with Blackkbox.ai
     */
    private void calculateAverageRequestTime(){
        long totalResponseTime = 0; // Initializes the total response time
        int count = 0; // Count of requests

        for (MongoLog log : logs) { // Iterates over the logs
            Date appRequestTime = log.getAppRequestTime(); // Gets the app request time
            Date appReplyTime = log.getAppReplyTime(); // Gets the App reply time
            if (appRequestTime != null && appReplyTime != null) { // Validates none of them are null
                long responseTime = appReplyTime.getTime() - appRequestTime.getTime();  // Calculates the response time in milliseconds
                totalResponseTime += responseTime; // Increases the total response time
                count++; // Increases the count
            }
        }
        averageRequestTime = count > 0 ? (double) totalResponseTime / count : 0; // Calculates the average response time
    }

}
