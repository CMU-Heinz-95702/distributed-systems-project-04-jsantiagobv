package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import java.util.Date;

/**
 * Class that represent a Log stored in MongoDC
 */
public class MongoLog {

    // Request-related attributes
    private String word; // Searched word
    private Date appRequestTime; // App request time
    private String deviceType; // Device type

    // API
    private Date apiRequestTime; // API request time
    private Date apiReplyTime; // API reply time
    private Integer apiResponseCode; // API resposne code
    private String apiResponseCodeDescription; // API response message

    // Reply
    private Date appReplyTime; // App reply time
    private Integer appResponseCode; // App response code
    private String appResponseCodeDescription; // App response message

    /**
     * Default constructor (with no arguments)
     */
    public MongoLog(){}

    /**
     * Constructs a MongoLog object with the provided details.
     */
    public MongoLog(String word, Date appRequestTime, String deviceType, Date apiRequestTime,
                    Date apiReplyTime, Integer apiResponseCode, String apiResponseCodeDescription,
                    Date appReplyTime, Integer appResponseCode, String appResponseCodeDescription) {
        this.word = word;
        this.appRequestTime = appRequestTime;
        this.deviceType = deviceType;
        this.apiRequestTime = apiRequestTime;
        this.apiReplyTime = apiReplyTime;
        this.apiResponseCode = apiResponseCode;
        this.apiResponseCodeDescription = apiResponseCodeDescription;
        this.appReplyTime = appReplyTime;
        this.appResponseCode = appResponseCode;
        this.appResponseCodeDescription = appResponseCodeDescription;
    }

    /**
     * Retrieves the word associated with the log entry.
     */
    public String getWord() {
        return word;
    }

    /**
     * Sets the word for this log entry.
     */
    public void setWord(String word) {
        this.word = word;
    }

    /**
     * Retrieves the application's request timestamp.
     */
    public Date getAppRequestTime() {
        return appRequestTime;
    }

    /**
     * Sets the application's request timestamp.
     */
    public void setAppRequestTime(Date appRequestTime) {
        this.appRequestTime = appRequestTime;
    }

    /**
     * Retrieves the type of device used for the request.
     */
    public String getDeviceType() {
        return deviceType;
    }

    /**
     * Sets the type of device used for the request.
     */
    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    /**
     * Retrieves the API request timestamp.
     */
    public Date getApiRequestTime() {
        return apiRequestTime;
    }

    /**
     * Sets the API request timestamp.
     */
    public void setApiRequestTime(Date apiRequestTime) {
        this.apiRequestTime = apiRequestTime;
    }

    /**
     * Retrieves the API response timestamp.
     */
    public Date getApiReplyTime() {
        return apiReplyTime;
    }

    /**
     * Sets the API response timestamp.
     */
    public void setApiReplyTime(Date apiReplyTime) {
        this.apiReplyTime = apiReplyTime;
    }

    /**
     * Retrieves the API response code.
     */
    public Integer getApiResponseCode() {
        return apiResponseCode;
    }

    /**
     * Sets the API response code.
     */
    public void setApiResponseCode(Integer apiResponseCode) {
        this.apiResponseCode = apiResponseCode;
    }

    /**
     * Retrieves the description of the API response code.
     */
    public String getApiResponseCodeDescription() {
        return apiResponseCodeDescription;
    }

    /**
     * Sets the description of the API response code.
     */
    public void setApiResponseCodeDescription(String apiResponseCodeDescription) {
        this.apiResponseCodeDescription = apiResponseCodeDescription;
    }

    /**
     * Retrieves the application's response timestamp.
     */
    public Date getAppReplyTime() {
        return appReplyTime;
    }

    /**
     * Sets the application's response timestamp.
     */
    public void setAppReplyTime(Date appReplyTime) {
        this.appReplyTime = appReplyTime;
    }

    /**
     * Retrieves the application's response code.
     */
    public Integer getAppResponseCode() {
        return appResponseCode;
    }

    /**
     * Sets the application's response code.
     */
    public void setAppResponseCode(Integer appResponseCode) {
        this.appResponseCode = appResponseCode;
    }

    /**
     * Retrieves the description of the application's response code.
     */
    public String getAppResponseCodeDescription() {
        return appResponseCodeDescription;
    }

    /**
     * Sets the description of the application's response code.
     */
    public void setAppResponseCodeDescription(String appResponseCodeDescription) {
        this.appResponseCodeDescription = appResponseCodeDescription;
    }

}
