package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import com.mongodb.*;
import com.mongodb.client.*;
import com.mongodb.client.result.InsertOneResult;
import org.bson.Document;
import org.bson.types.ObjectId;
import java.util.Date;

/**
 * Class in charge of register a log in MongoDB
 * This class was build using the MongoDB example in https://www.mongodb.com/developer/languages/java/java-setup-crud-operations/
 * Also, I used ChatGPT and Blackbox.ai
 */
public class MongoLogger {

    private static final String connectionString = // URL for the connection with MongoDB
            "mongodb+srv://jsantiagobv:SHIRO123@cluster.y4hq5.mongodb.net/?retryWrites=true&w=majority&appName=Cluster";

    private MongoLog mongoLog; // Log to be registered

    /**
     * Constructor method
     */
    public MongoLogger() { this.mongoLog = new MongoLog();} // Initializes a new MongoLog

    /**
     * Sets the application's request timestamp in the associated MongoLog.
     */
    public void setAppRequestTime(Date appRequestTime) {
        this.mongoLog.setAppRequestTime(appRequestTime);
    }

    /**
     * Sets the type of device used for the request in the associated MongoLog.
     */
    public void setDeviceType(String deviceType) {
        this.mongoLog.setDeviceType(deviceType);
    }

    /**
     * Sets the word associated with the log in the associated MongoLog.
     *
     */
    public void setWord(String word) {
        this.mongoLog.setWord(word);
    }

    /**
     * Sets the API request timestamp in the associated MongoLog.
     */
    public void setApiRequestTime(Date apiRequestTime) {
        this.mongoLog.setApiRequestTime(apiRequestTime);
    }

    /**
     * Sets the API reply timestamp in the associated MongoLog.
     */
    public void setApiReplyTime(Date apiReplyTime) {
        this.mongoLog.setApiReplyTime(apiReplyTime);
    }

    /**
     * Sets the API response code in the associated MongoLog.
     */
    public void setApiResponseCode(int apiResponseCode) {
        this.mongoLog.setApiResponseCode(apiResponseCode);
    }

    /**
     * Sets the description of the API response code in the associated MongoLog.
     */
    public void setApiResponseCodeDescription(String apiResponseCodeDescription) {
        this.mongoLog.setApiResponseCodeDescription(apiResponseCodeDescription);
    }

    /**
     * Sets the application's reply timestamp in the associated MongoLog.
     */
    public void setAppReplyTime(Date appReplyTime) {
        this.mongoLog.setAppReplyTime(appReplyTime);
    }

    /**
     * Sets the application's response code in the associated MongoLog.
     */
    public void setAppResponseCode(int appResponseCode) {
        this.mongoLog.setAppResponseCode(appResponseCode);
    }

    /**
     * Sets the description of the application's response code in the associated MongoLog.
     */
    public void setAppResponseCodeDescription(String appResponseCodeDescription) {
        this.mongoLog.setAppResponseCodeDescription(appResponseCodeDescription);
    }

    /**
     * Stores one log in MongoDB.
     * Implementation based on the code provided by Mongo.
     */
    public void storeLog(){
        ServerApi serverApi = ServerApi.builder() // Configures the Server API version for MongoDB
                .version(ServerApiVersion.V1)
                .build();

        MongoClientSettings settings = MongoClientSettings.builder() // Builds the MongoClientSettings using the connection string and server API configuration
                .applyConnectionString(new ConnectionString(connectionString))
                .serverApi(serverApi)
                .build();

        try{
            MongoClient mongoClient = MongoClients.create(settings); // Creates a MongoClient instance with the specified settings
            MongoDatabase database = mongoClient.getDatabase("project4"); // Gets the reference to the "project4" database
            MongoCollection<Document> collection = database.getCollection("dictionary"); // Gets the reference to the "dictionary" collection within the database

            try {
                InsertOneResult result = collection.insertOne(new Document() // Initializes a new document
                        .append("_id", new ObjectId()) // Adds an ID
                        .append("word", mongoLog.getWord()) // Adds the word
                        .append("deviceType", mongoLog.getDeviceType()) // Adds the device type
                        .append("appRequestTime", mongoLog.getAppRequestTime()) // Adds the app request time
                        .append("apiRequestTime", mongoLog.getApiRequestTime()) // Adds the api request time
                        .append("apiReplyTime", mongoLog.getApiReplyTime()) // Adds the api reply time
                        .append("apiResponseCode", mongoLog.getApiResponseCode()) // Adds the api response code
                        .append("apiResponseCodeDescription", mongoLog.getApiResponseCodeDescription()) // Adds the api response message
                        .append("appReplyTime", mongoLog.getAppReplyTime()) // Adds the app reply time
                        .append("appResponseCode", mongoLog.getAppResponseCode()) // Adds the app response code
                        .append("appResponseCodeDescription", mongoLog.getAppResponseCodeDescription())); // Adds the app response message
                System.out.println("Success! Inserted document id: " + result.getInsertedId()); // Prints the ID of the inserted document

            } catch (MongoException me) {
                System.err.println("Unable to insert due to an error: " + me); // Prints a message if any exceptions occur during the operation
            } finally { mongoClient.close();} // Closes the connection with Mongo

        } catch (Exception e) { // Catches errors
            e.printStackTrace(); // Prints the stacktrace
        }
    }

}
