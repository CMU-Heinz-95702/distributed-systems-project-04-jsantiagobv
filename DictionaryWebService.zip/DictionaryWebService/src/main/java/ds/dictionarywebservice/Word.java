package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import java.util.ArrayList;

/**
 * Class that represents a word in the Response format
 */
public class Word {
    String word; // Word
    String phonetic; // Phonetic
    ArrayList<Meaning> meanings; // Meanings
}

/**
 * Class that represent a meaning
 */
class Meaning {
    String partOfSpeech; // Part of speech
    String definition; // Definition
}

