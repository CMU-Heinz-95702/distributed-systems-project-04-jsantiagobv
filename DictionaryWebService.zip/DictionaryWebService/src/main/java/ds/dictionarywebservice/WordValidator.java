package ds.dictionarywebservice;

/**
 * Author: Jesus Santiago Bolaños Vega
 * Email: sbolaosv@andrew.cmu.edu
 */

import java.util.regex.Pattern;

/**
 * Class that validates if a word is correct before consuming the API
 * I made this class with ChatGPT
 */
public class WordValidator {

    /**
     * Static method that validates the input
     */
    public static void validateWord(String input) throws InvalidWordException {
        if (input == null || input.isEmpty()) { // Validates if the word is null or empty
            throw new InvalidWordException("Input cannot be null or empty"); // Throws an InvalidWordException
        }

        Pattern pattern = Pattern.compile("^[a-zA-Z]+$"); // Regex to match alphabetic words (only letters, no numbers or special characters)
        if (!pattern.matcher(input).matches()) { // Validates if the word does not match the pattern
            throw new InvalidWordException("Invalid input: '" + input + "' contains non-alphabetic characters."); // Throes an InvalidWordException
        }
    }
}
